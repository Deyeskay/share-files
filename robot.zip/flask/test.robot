*** Settings ***
Library    Browser
Library    RequestsLibrary
Library    Collections
Library    String

*** Variables ***
${MOCK_SERVER}    http://localhost:5000

*** Test Cases ***
Realtime API Mocking
    ${session}=    Generate Random String    8

    New Browser    chromium    headless=False
    New Context    extraHTTPHeaders={"x-session-id": "${session}"}
    New Page    https://your-app-url.com

    # Set initial mock
    Create Session    mock    ${MOCK_SERVER}
    ${body}=    Create Dictionary
    ...    session=${session}
    ...    endpoint=api/user
    ...    response={"name": "SK", "role": "tester"}

    POST On Session    mock    /set_mock    json=${body}

    # Intercept API
    Route Requests    **/api/user    Handle Mock    ${session}

    Reload

    Sleep    3

    # Change mock dynamically
    ${new_body}=    Create Dictionary
    ...    session=${session}
    ...    endpoint=api/user
    ...    response={"name": "SK", "role": "admin"}

    POST On Session    mock    /set_mock    json=${new_body}

    Reload