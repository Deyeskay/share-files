from flask import Flask, request, jsonify

app = Flask(__name__)

# Store mocks per session
mock_store = {}

@app.route('/set_mock', methods=['POST'])
def set_mock():
    data = request.json
    session = data['session']
    endpoint = data['endpoint']
    response = data['response']

    if session not in mock_store:
        mock_store[session] = {}

    mock_store[session][endpoint] = response
    return {"status": "mock set"}

@app.route('/mock/<session>/<path:endpoint>', methods=['GET', 'POST'])
def get_mock(session, endpoint):
    session_data = mock_store.get(session, {})
    response = session_data.get(endpoint, {"error": "no mock"})

    return jsonify(response)

if __name__ == '__main__':
    app.run(port=5000)