from Browser import Browser
import requests

class MockHandler:
    def handle_mock(self, route, session):
        url = route.request.url

        endpoint = url.split("/api/")[-1]

        mock_url = f"http://localhost:5000/mock/{session}/api/{endpoint}"

        response = requests.get(mock_url)

        route.fulfill(
            status=200,
            body=response.text,
            headers={"Content-Type": "application/json"}
        )