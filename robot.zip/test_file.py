class TextFile:

    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    def __init__(self):
        pass

    def read_text_file(self, file_path):
        """Reads content from a text file and returns it"""
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        return content

    def write_text_file(self, file_path, content):
        """Writes content to a text file"""
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(content)
        return "File written successfully"

    def append_text_file(self, file_path, content):
        """Appends content to a text file"""
        with open(file_path, 'a', encoding='utf-8') as file:
            file.write(content + "\n")
        return "Content appended successfully"