class MyLibrary:
    def calculate_sum(self, a, b):
        """Calculates the sum of two numbers."""
        return int(a) + int(b)

    def greet_user(self, name):
        """Returns a greeting message."""
        return f"Hello, {name}! Welcome to Robot Framework."