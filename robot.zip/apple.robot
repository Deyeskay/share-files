*** Settings ***
Library    FastHTTPMock
Library    RequestsLibrary
Library    Browser    enable_network_interception=${True}
Library    Collections

*** Variables ***
${BASE_URL}    http://localhost:5000

*** Test Cases ***
Mock API In Parallel
    # 🚀 Start mock server (runs parallel to test)
    Start Mock Server    port=5000

    # 🎯 Define request pattern
    ${request}=    Create Dictionary
    ...    method=GET
    ...    path=/api/v1/fruits

    # 🎯 Define mock response
    ${response}=    Create Dictionary
    ...    status=200
    ...    headers={"Content-Type":"application/json"}
    ...    body=[{"name":"Mango","id":1}]

    # 🔥 Register mock
    Add Mock Interaction    ${request}    ${response}

    # 🌐 Call API (this hits mock server)
    Create Session    mysession    ${BASE_URL}
    ${resp}=    GET On Session    mysession    /api/v1/fruits

    Log    ${resp.text}

    Should Be Equal As Strings    ${resp.text}    [{"name":"Mango","id":1}]


 
*** Test Cases ***
Scenario: Overwriting Data via JavaScript
    New Browser    chromium    headless=False
    New Page       https://demo.playwright.dev/api-mocking
    
    # We use JavaScript to 'patch' the fetch function
    Execute JavaScript    
    ...    window.fetch = async (...args) => {
    ...      if (args[0].includes('api/v1/fruits')) {
    ...        return new Response(JSON.stringify([{ name: 'JS Mocked Fruit', id: 1 }]), {
    ...          status: 200,
    ...          headers: { 'Content-Type': 'application/json' }
    ...        });
    ...      }
    ...      return window.fetch(...args);
    ...    };

    # Reload the page to trigger the patched fetch
    Reload
    Get Text    text=JS Mocked Fruit