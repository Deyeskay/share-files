*** Settings ***
Library    Playwright

*** Test Cases ***
Mock API And Continue UI Flow
    New Browser    chromium    headless=False
    New Context
    New Page

    # 🔥 MOCK API (native support)
    Route    **/api/v1/fruits
    ...    status=200
    ...    body=[{"name":"Strawberry","id":21}]

    Go To    https://demo.playwright.dev/api-mocking

    # ✅ Now continue normal Robot steps
    Wait For Selector    text=Strawberry

    Click    text=Strawberry

    Log    Click successful