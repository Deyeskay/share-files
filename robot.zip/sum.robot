*** Settings ***
Library    MyLibrary.py

*** Test Cases ***
Example Test
    ${sum}=    Calculate Sum    10    20
    Log    The result is ${sum}
    
    ${msg}=    Greet User    RobotUser
    Log    ${msg}