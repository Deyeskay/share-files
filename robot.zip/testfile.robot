*** Settings ***
Library    text_file.py

*** Variables ***
${FILE_PATH}    sample.txt

*** Test Cases ***
Test Write File
    ${result}=    Write Text File    ${FILE_PATH}    Hello Mohith!
    Log    ${result}

Test Read File
    ${content}=    Read Text File    ${FILE_PATH}
    Log    ${content}

Test Append File
    ${result}=    Append Text File    ${FILE_PATH}    This is appended line
    Log    ${result}