import pytest
import time
from playwright.sync_api import Page, expect


def test_mock_api(page: Page):
    # 1. Define the mock (detect and replace)
    # This matches any call ending in /api/v1/fruits
    page.route("**/api/v1/fruits", lambda route: route.fulfill(
        status=200,
        content_type="application/json",
        json=[{"name": "strawberry", "id": 1}]
    ))

    # 2. Open the URL
    page.goto("https://demo.playwright.dev/api-mocking/")

    # 3. Verify the UI shows your mock data
    expect(page.get_by_text("strawberry")).to_be_visible()
    time.sleep(10)  # Just to visually confirm the result before the test ends