*** Settings ***
Library    Browser

*** Test Cases ***
Mock API and Click Element
    # 1. Setup the browser and navigate to your page
    New Browser    chromium    headless=False
    New Context
    New Page       https://your-app-url.com
    
    # 2. Mock the API call before it happens (or before reload)
    # We use Playwright's internal 'page.route' via JavaScript
    Execute JavaScript    
    ...    async () => {
    ...        await window.page.route('**/api/user/profile', route => {
    ...            route.fulfill({
    ...                status: 200,
    ...                contentType: 'application/json',
    ...                body: JSON.stringify({
    ...                    "name": "Mocked User",
    ...                    "role": "Admin",
    ...                    "status": "Active"
    ...                })
    ...            });
    ...        });
    ...    }

    # 3. Reload to ensure the page fetches the mocked data
    Reload
    
    # 4. Validate the mocked data is rendered
    Get Text    id=user-name-display    ==    Mocked User
    
    # 5. Continue with your existing requirement: Click element
    Click    id=admin-dashboard-button