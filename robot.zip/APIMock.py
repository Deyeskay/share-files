from robot.libraries.BuiltIn import BuiltIn
from robot.api.deco import keyword
from playwright.sync_api import sync_playwright

class APIMock:

    @keyword("Mock Fruits API")
    def mock_fruits_api(self):
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            context = browser.new_context()

            context.route("**/api/v1/fruits", lambda route: route.fulfill(
                status=200,
                content_type="application/json",
                body='[{"name":"Strawberry","id":21}]'
            ))

            page = context.new_page()
            page.goto("https://demo.playwright.dev/api-mocking")

            #page.click("text=Strawberry")

            #browser.close()