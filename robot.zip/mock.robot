*** Settings ***
Library    Browser
Library    APIMock.py

*** Test Cases ***
Mock Fruits API In Demo App
    New Browser    chromium    headless=False
    New Context
    New Page

    # 🔥 Attach mock BEFORE navigation
    Mock Fruits API

    #Go To    https://demo.playwright.dev/api-mocking

    Wait For Elements State    text=Strawberry    visible