*** Settings ***
Library    Browser
Library    MockHandler.py

*** Test Cases ***
Mock Fruits API And Click
    New Browser    chromium    headless=False
    New Context
    New Page    https://demo.playwright.dev/api-mocking

    # 👇 Intercept BEFORE page loads API
    Route    **/api/v1/fruits    Mock Fruits Response

    Reload

    # 👇 Now click button on mocked UI
    Click    text=Get fruits

    # Validate mocked data is shown
    Wait For Elements State    text=Dragonfruit    visible