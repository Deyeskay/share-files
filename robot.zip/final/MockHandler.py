class MockHandler:
    def mock_fruits_response(self, route):
        mock_json = """
        [
            {"name": "Dragonfruit", "id": 100},
            {"name": "Apple", "id": 101}
        ]
        """

        route.fulfill(
            status=200,
            body=mock_json,
            headers={"Content-Type": "application/json"}
        )