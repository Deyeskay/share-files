*** Settings ***
Library    Process

*** Test Cases ***
Run Playwright Mock Test
    Run Process    python    mock_runner.py    shell=True