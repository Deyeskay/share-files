
from playwright.sync_api import sync_playwright

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()

        # ✅ MOCK API
        def handle_route(route):
            route.fulfill(
                status=200,
                content_type="application/json",
                body='[{"name":"Strawberry","id":21}]'
            )

        context.route("**/api/v1/fruits", handle_route)

        page = context.new_page()
        page.goto("https://demo.playwright.dev/api-mocking")

        page.wait_for_selector("text=Strawberry")

        print("✅ Mock worked!")

        page.wait_for_timeout(3000)
        browser.close()

if __name__ == "__main__":
    run()